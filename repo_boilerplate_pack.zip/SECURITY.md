# Security Policy

## Supported Versions
The `main` branch and the latest tagged release receive security updates.

## Reporting a Vulnerability
Please email the maintainers or open a Private Vulnerability Report on GitHub (Security tab). Include:
- Version / commit SHA
- Steps to reproduce
- Expected vs actual behavior
- Any mitigation ideas

We'll acknowledge receipt within 72 hours.
