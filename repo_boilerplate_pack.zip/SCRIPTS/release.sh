#!/usr/bin/env bash
set -euo pipefail
ver=${1:-0.1.0}
git tag -a "v${ver}" -m "Release v${ver}"
git push origin "v${ver}"
echo "Remember to draft a GitHub Release from tag v${ver}."
