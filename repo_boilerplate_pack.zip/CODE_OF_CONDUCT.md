# Code of Conduct

We follow the Contributor Covenant (v2.1). By participating, you agree to uphold a harassment-free, inclusive environment.

- Be respectful and constructive.
- Assume good intent; disagree respectfully.
- No harassment, hate speech, or discrimination.

Instances of abusive behavior may be reported to the maintainers.
