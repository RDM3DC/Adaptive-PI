Add near the top of README.md:

![CI](https://github.com/RDM3DC/Adaptive-PI/actions/workflows/ci.yml/badge.svg)
![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)
![Python](https://img.shields.io/badge/python-3.10_|_3.11_|_3.12-blue)
