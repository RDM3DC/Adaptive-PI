## Summary
- [ ] Motivation
- [ ] Approach
- [ ] Tests

## Checklist
- [ ] Tests pass (`pytest -q`)
- [ ] Lints pass (`pre-commit run -a`)
- [ ] Docs updated (if user-facing)
