# Changelog
All notable changes to this project will be documented in this file.

## [0.1.0] - YYYY-MM-DD
### Added
- Initial release of Adaptive-PI with πₐ geometry core, inversion utilities, geodesic simulator, and IMO examples.
