# Contributing to Adaptive-PI

Thanks for your interest! A quick guide to contributing:

1. Fork and create a feature branch from `main`.
2. Install dev deps: `pip install -e ".[dev]"`.
3. Run tests: `pytest -q`.
4. Lint/format: `pre-commit run -a` (see `.pre-commit-config.yaml`).
5. Open a PR describing motivation, approach, and tests.

## Development tips
- Keep functions pure when possible; add docstrings.
- Flat-limit tests (K=0) should always pass.
- Add a minimal example to `examples/` if you add a new API.

## Commit style
Conventional commits (e.g., `feat:`, `fix:`, `docs:`) are encouraged.
